Pour compiler, vous devez avoir installé les librairies Adafruit_Sensor-master, 
DFRobot_ADS1115-1.0.0 et DHT_sensor_library-1.4.3 présentes sur notre github.