#ifndef COMPOSANT_FILE_H
#define COMPOSANT_FILE_H

class Composant{
  private :
  int pin;
  
  public :

  //Méthodes
  int GetPin();

  //Constructeur 
  Composant(int p);
  
};

#endif //COMPOSANT_FILE_H
