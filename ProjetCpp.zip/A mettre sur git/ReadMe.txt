MOREAU Julie
RONTARD Madeline
4AE-SE groupe 3

Ouvrir le fichier .ino dans MoniteurPlante
Pour pouvoir compiler le projet, deziper librairies.zip
L'explication du projet se trouve dans le rapport en pdf
